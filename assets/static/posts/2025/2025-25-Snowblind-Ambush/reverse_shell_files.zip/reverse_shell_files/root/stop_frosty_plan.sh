#!/usr/bin/bash

echo "Welcome back, Frosty! Getting cold feet?"
echo "Here is your secret key to plug in your badge and stop the plan:"
curl -X POST "$CHATBOT_URL/api/submit_c05730b46d0f30c9d068343e9d036f80" -H "Content-Type: Application/json" -d "{\"challenge_hash\":\"ec87937a7162c2e258b2d99518016649\"}"